<?php 
echo "Hello world"; ?>
