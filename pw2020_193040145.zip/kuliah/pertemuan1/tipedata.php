<?php 
	// pembuatan variabel
	
	$nama_variabel = "VALUE";

	//data pribadi
	$nama = "Ferry SM"; //string
	$umur = 25;

	echo $nama;
	echo "<br>";
	echo $umur. "Tahun";

 ?>
