<?php 
//	$nilai = 51;
//	if ($nilai <= 55) {
//		echo "Tidak Lulus";
//	}
//	else {
//		echo "";
//	}


$nilai = 10;

$hasil = ($nilai%2 == 0)? "genap":"ganjil";
echo "$hasil";

// PENGKONDISIAN IF ELSE IF

// 	$warna_lampu = "merah";

// 	if($warna_lampu == "merah"){
// 		echo "Berhenti";
// 	}
// 	elseif ($warna_lampu == "kuning"){
// 		echo "Bersiap";
// 	}
// 	elseif ($warna_lampu == "hijau"){
// 		echo "Maju";
// 	}
// 	else{
// 		echo "warna Tidak Dikenal";

// 	}

// $hari

// if ($hari <=1 ) {
// 	echo "Hari Minggu";
// }


// switch ($hari) {
// 	case 'value':
// 		# code...
// 		break;
	
// 	default:
// 		# code...
// 		break;
// }












 ?>