<?php 
	for ($i=0; $i <9 ; $i++) { 
		echo "Nilai ".$i. "<br>";
	}

	// $i = 0;
	// while ($i <= 10) {
	// 	echo "Nilai".$i."<br>";
	// 	$i++;
	// }

	// echo "Nilai akhir i = ".$i;

// do {
// 	echo "Nilai".$i."<br>";
// 	$si++
// } while ($i < 10);
// 	echo "Nilai akhir i = ".$i;


 ?>