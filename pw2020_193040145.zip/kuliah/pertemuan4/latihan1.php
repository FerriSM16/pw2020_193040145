<?php 
	
	$tulisan = "Balonku ada lima
				rupa-rupa warnanya
				hijau, kuning, kelabu
				merah muda dan biru
				meletus balon hijau Dor
				hatiku sangat kacau
				balonku tinggal empat
				kupegang erat-erat";
	echo str_replace("a", "o", $tulisan) ."</br>";

 ?>