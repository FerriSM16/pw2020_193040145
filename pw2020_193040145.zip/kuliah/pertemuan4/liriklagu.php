<?php 

$lirik = "Lihat kebunku <br> penuh dengan bunga <br>
		  ada yang putih,<br> dan ada yang merah <br>
		  setiap hari <br> kusiram semua <br> 
		  mawar melati, <br> semuanya indah <br>";

	$lirik = str_replace("a", "o", $lirik);
	$lirik = str_replace("i", "o", $lirik);
	$lirik = str_replace("u", "o", $lirik);
	$lirik = str_replace("e", "o", $lirik);

 ?>