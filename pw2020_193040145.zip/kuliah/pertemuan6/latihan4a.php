<?php 

	$kata = array("epan", "cipta", "akan", "u", "asa", "esok");
	echo "m" .$kata[4]." d".$kata[0]."mu di".$kata[1]."kan oleh apa yang ka".$kata[3]." kerj".$kata[2]." hari ini, b".$kata[3]."kan b".$kata[5];

 ?>