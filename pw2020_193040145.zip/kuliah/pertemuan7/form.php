<!DOCTYPE html>
<html>
<head>
	<title>FORM</title>
</head>
<body>
		<form method="get" action="resault.php">
			<table>
				<tr>
					<td>Username</td>
					<td><input type="text" name="Username"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="Password"></td>
				</tr>
				<tr>
					<td></td>
					<td><button type="Submit">Login</button></td>
				</tr>
			</table>
		</form>
</body>
</html>