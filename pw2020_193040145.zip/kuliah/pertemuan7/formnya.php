<!DOCTYPE html>
<html>
<head>
	<title>FORM</title>
</head>
<body>
		<form method="get" action="formnya.php">
			<table>
				<tr>
					<td>No. KTP</td>
					<td><input type="text" name="No. KTP"></td>
				</tr>
				<tr>
					<td>Nama</td>
					<td><input type="password" name="Nama"></td>
				</tr>
				<tr>
					<td>Alamat</td>
					<td><input type="password" name="Alamat"></td>
				</tr>
				<tr>
					<td></td>
					<td><button type="Submit">Daftar</button></td>
				</tr>
			</table>
		</form>
</body>
</html>