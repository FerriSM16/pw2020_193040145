<!DOCTYPE html>
<html>
<head>
	<title>FORM</title>
</head>
<body>
		<form method="get" action="hasilaritmatika.php">
			<table>
				<tr>
					<td>Angka1</td>
					<td><input type="number" name="Angka1"></td>
				</tr>
				<tr>
					<td>Angka2</td>
					<td><input type="number" name="Angka2"></td>
				</tr>
				<tr>
					<td></td>
					<td><button type="Submit">Jumlahkan</button></td>
				</tr>
			</table>
		</form>
</body>
</html>