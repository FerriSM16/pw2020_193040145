<?php 
	
	echo "<h5>Daftar Peserta</h5>";
	echo "No. KTP : ".$GET['ktp']."</br>";
	echo "Nama : ".$GET['nama']."</br>";
	echo "Alamat : ".$GET['alamat']."</br>";
 ?>